const num1 = 10;
const num2 = 20;

const sum = () => num1 + num2;
const sub = () => num1 - num2;

export{num1, num2, sum};

export default sub;